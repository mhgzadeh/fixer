from get_data.handler import get_rates

__all__ = ['get_rates']
def get_rates():
    print('Sucessfully got rates.')

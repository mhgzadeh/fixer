from setuptools import setup

setup(
    name='mohammad',
    version='0.0.2',
    description='fixer service packages: providing important worlds currencies.',
    url='https://github.com/mhgzadeh/fixer.git',
    author='Mohammad',
    author_email='m.hgzadeh@gmail.com',
    license='MTL',
    packages=['get_data'],
    zip_safe=False
)
